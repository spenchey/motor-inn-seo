# toyota-dealers-in-iowa: placement instructions

**Status:** `draft-needs-owner-approval`. Do not publish until Spencer approves in writing.
**Site:** www.motorinntoyotaofcarroll.com (Motor Inn Toyota of Carroll)
**URL path:** /toyota-dealers-in-iowa
**Canonical:** https://www.motorinntoyotaofcarroll.com/toyota-dealers-in-iowa

## Type: NEW content page

- Create a standard DealerOn content page at the path above using the site's existing header, nav and footer.
- **Page title:** Toyota Dealer in Iowa | Motor Inn Toyota of Carroll
- **Meta description:** Looking for a Toyota dealer in Iowa? Motor Inn Toyota of Carroll is at 1526 Le Clark Road, Carroll, off US 30. New, Certified, service. (712) 792-5000.
- **H1:** Toyota Dealer in West-Central Iowa: Motor Inn Toyota of Carroll
- Breadcrumb: Home > Toyota Dealer in West-Central Iowa
- Paste `index.html` into the page body. `full-html/index.html` is a full-page fallback built on this site's live inner-page template (captured 2026-11-23T18:29Z).
- Do not add the page to the main navigation unless Spencer asks.

## Structured data
- The body ends with one JSON-LD block (WebPage + AutoDealer + FAQPage). Keep it with the visible FAQ section, and keep the site's own sitewide schema too.

## Redirects
- None for this page in this request.

## Internal links
- Links inside the body point only to pages that already exist (checked against the live sitemaps and a live link check on 2026-11-23).
- After this page is live, add these links (Spencer will confirm):
  - Link this page from the Toyota homepage or /aboutus.aspx, and from motorinnautogroup.com/contactus.aspx.
  - Link /toyota-tacoma-tundra-for-sale-carroll-iowa and /toyota-sequoia-sienna-for-sale-carroll-iowa from the 'What can I buy' list once they are live.
