# toyota-sequoia-sienna-for-sale-carroll-iowa: placement instructions

**Status:** `draft-needs-owner-approval`. Do not publish until Spencer approves in writing.
**Site:** www.motorinntoyotaofcarroll.com (Motor Inn Toyota of Carroll)
**URL path:** /toyota-sequoia-sienna-for-sale-carroll-iowa
**Canonical:** https://www.motorinntoyotaofcarroll.com/toyota-sequoia-sienna-for-sale-carroll-iowa

## Type: NEW content page

- Create a standard DealerOn content page at the path above using the site's existing header, nav and footer.
- **Page title:** Sequoia & Sienna for Sale in Carroll, IA | Motor Inn Toyota
- **Meta description:** Shop the Toyota Sequoia SUV and Sienna minivan at Motor Inn Toyota of Carroll, 1526 Le Clark Road, Carroll, Iowa. Test drives: (712) 792-5000.
- **H1:** Toyota Sequoia and Sienna for Sale in Carroll, Iowa
- Breadcrumb: Home > Toyota Sequoia and Sienna for Sale in Carroll, Iowa
- Paste `index.html` into the page body. `full-html/index.html` is a full-page fallback built on this site's live inner-page template (captured 2026-11-23T18:29Z).
- Do not add the page to the main navigation unless Spencer asks.

## Structured data
- The body ends with one JSON-LD block (WebPage + AutoDealer + FAQPage). Keep it with the visible FAQ section, and keep the site's own sitewide schema too.

## Redirects
- None for this page in this request.

## Internal links
- Links inside the body point only to pages that already exist (checked against the live sitemaps and a live link check on 2026-11-23).
- After this page is live, add these links (Spencer will confirm):
  - Link from /toyota-dealers-in-iowa ('What can I buy') once live, and from the /toyota-sienna and /2026-toyota-sequoia.html model pages.
