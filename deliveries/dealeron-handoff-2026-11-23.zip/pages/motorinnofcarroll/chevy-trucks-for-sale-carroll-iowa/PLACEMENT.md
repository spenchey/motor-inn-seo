# chevy-trucks-for-sale-carroll-iowa: placement instructions

**Status:** `draft-needs-owner-approval`. Do not publish until Spencer approves in writing.
**Site:** www.motorinnofcarroll.com (Motor Inn Chevrolet of Carroll)
**URL path:** /chevy-trucks-for-sale-carroll-iowa
**Canonical:** https://www.motorinnofcarroll.com/chevy-trucks-for-sale-carroll-iowa

## Type: NEW content page

- Create a standard DealerOn content page at the path above using the site's existing header, nav and footer.
- **Page title:** Chevy Trucks for Sale in Carroll, IA | Motor Inn of Carroll
- **Meta description:** Chevy trucks for sale in Carroll, Iowa: Colorado, Silverado 1500, Silverado HD and Silverado EV at Motor Inn Chevrolet of Carroll. Call (712) 792-5000.
- **H1:** Chevy Trucks for Sale in Carroll, Iowa
- Breadcrumb: Home > Chevy Trucks for Sale in Carroll, Iowa
- Paste `index.html` into the page body. `full-html/index.html` is a full-page fallback built on this site's live inner-page template (captured 2026-11-23T18:29Z).
- Do not add the page to the main navigation unless Spencer asks.

## Structured data
- The body ends with one JSON-LD block (WebPage + AutoDealer + FAQPage). Keep it with the visible FAQ section, and keep the site's own sitewide schema too.

## Redirects
- None for this page in this request.

## Internal links
- Links inside the body point only to pages that already exist (checked against the live sitemaps and a live link check on 2026-11-23).
- After this page is live, add these links (Spencer will confirm):
  - Link from /chevy-dealer-carroll-iowa (Trucks bullet) once live.
