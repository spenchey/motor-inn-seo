# chevy-dealer-carroll-iowa: placement instructions

**Status:** `draft-needs-owner-approval`. Do not publish until Spencer approves in writing.
**Site:** www.motorinnofcarroll.com (Motor Inn Chevrolet of Carroll)
**URL path:** /chevy-dealer-carroll-iowa
**Canonical:** https://www.motorinnofcarroll.com/chevy-dealer-carroll-iowa

## Type: NEW content page

- Create a standard DealerOn content page at the path above using the site's existing header, nav and footer.
- **Page title:** Chevy Dealer in Carroll, Iowa | Motor Inn of Carroll
- **Meta description:** Motor Inn Chevrolet of Carroll, Chevy dealer at 1526 Le Clark Road, Carroll, Iowa. New Chevy trucks and SUVs, used cars and service. (712) 792-5000.
- **H1:** Chevy Dealer in Carroll, Iowa: Motor Inn Chevrolet of Carroll
- Breadcrumb: Home > Chevy Dealer in Carroll, Iowa
- Paste `index.html` into the page body. `full-html/index.html` is a full-page fallback built on this site's live inner-page template (captured 2026-11-23T18:29Z).
- Do not add the page to the main navigation unless Spencer asks.

## Structured data
- The body ends with one JSON-LD block (WebPage + AutoDealer + FAQPage). Keep it with the visible FAQ section, and keep the site's own sitewide schema too.

## Redirects
- None for this page in this request.

## Internal links
- Links inside the body point only to pages that already exist (checked against the live sitemaps and a live link check on 2026-11-23).
- After this page is live, add these links (Spencer will confirm):
  - Add a link to this page from motorinnofcarroll.com/aboutus.aspx and the Chevy homepage, so it isn't orphaned.
  - Link this page from the new chevy-suvs, chevy-blazer and chevy-trucks pages, and the reverse, once all four are live.
  - Link from motorinnautogroup.com/contactus.aspx ('Chevy dealer in Carroll').
