# used-cars-carroll-iowa: placement instructions

**Status:** `draft-needs-owner-approval`. Do not publish until Spencer approves in writing.
**Site:** www.motorinnautogroup.com (Motor Inn Auto Group)
**URL path:** /used-cars-carroll-iowa
**Canonical:** https://www.motorinnautogroup.com/used-cars-carroll-iowa

## Type: update to an EXISTING page (cycle 1 of 2)

Replace the body copy of the live /used-cars-carroll-iowa page in cycle 1. Keep the live title, meta and H1 until cycle 2.

- **Keep the page's current title, meta description and H1 exactly as they are live.** The values in metadata-all.csv marked `cycle2_*` are for a later, separate request.
- Paste `index.html` into the page's editable content region.
- Keep the page's existing H1 ("Used cars in Carroll, Iowa", which sits at the top of the editable body) exactly as it is.
- Replace everything in the body **below that H1** with `index.html`. This also removes the outdated phone number (712) 522-2526 that the live page currently shows three times.
- `full-html/index.html` is a **placement preview** built from the live page captured 2026-11-23T18:29Z. It is for checking position only, not for upload.

## Structured data
- The body ends with one JSON-LD block (WebPage + AutoDealer + FAQPage). Keep it with the visible FAQ section, and keep the site's own sitewide schema too.

## Redirects
- None for this page in this request.

## Internal links
- Links inside the body point only to pages that already exist (checked against the live sitemaps and a live link check on 2026-11-23).
- After this page is live, add these links (Spencer will confirm):
  - Sibling: link to /best-place-to-buy-used-car-carroll-iowa (live) from the 'Which used car dealers in Carroll, IA also service what they sell?' section if Spencer wants a second used-car entry point.
