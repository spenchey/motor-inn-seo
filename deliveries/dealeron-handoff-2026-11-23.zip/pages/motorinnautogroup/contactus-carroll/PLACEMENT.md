# contactus-carroll: placement instructions

**Status:** `draft-needs-owner-approval`. Do not publish until Spencer approves in writing.
**Site:** www.motorinnautogroup.com (Motor Inn Auto Group)
**URL path:** /contactus.aspx
**Canonical:** https://www.motorinnautogroup.com/contactus.aspx

## Type: update to an EXISTING page (cycle 1 of 2)

Add the sections and FAQ below as one content block BELOW the existing contact form on /contactus.aspx. Keep the page's current title, meta and H1 in cycle 1. The H1 line below is the proposed cycle-2 heading. Until then, render it as styled text, not a second H1.

- **Keep the page's current title, meta description and H1 exactly as they are live.** The values in metadata-all.csv marked `cycle2_*` are for a later, separate request.
- Paste `index.html` into the page's editable content region.
- Place it **below the existing contact form**. The form must stay first on the page.
- Do not change the form, its fields or its consent text.
- `full-html/index.html` is a **placement preview** built from the live page captured 2026-11-23T18:29Z. It is for checking position only, not for upload.

## Structured data
- The body ends with one JSON-LD block (WebPage + AutoDealer + FAQPage). Keep it with the visible FAQ section, and keep the site's own sitewide schema too.

## Redirects
- None for this page in this request.
- A **separate, later** request (EMAIL-DRAFTS/04) will 301 /car-dealerships-carroll-iowa, /car-dealerships-in-carroll-iowa.html and /car-dealership-carroll-iowa to /contactus.aspx. Do not do that as part of this page update.

## Internal links
- Links inside the body point only to pages that already exist (checked against the live sitemaps and a live link check on 2026-11-23).
- After this page is live, add these links (Spencer will confirm):
  - Link 'Chevy dealer in Carroll' -> motorinnofcarroll.com/chevy-dealer-carroll-iowa once it is live.
  - Link 'Toyota dealer in Iowa' -> motorinntoyotaofcarroll.com/toyota-dealers-in-iowa once it is live.
