# Motor Inn Auto Group — DealerOn handoff (2026-11-06)

## What this package is
- Ten final, approved, QA-checked pages for DealerOn publishing.
- Each page has a body-only HTML file and a full-html fallback.
- The pages use the same DealerOn chrome and template system QA checked.
- No live site changes or sends happened as part of this build.

## How the zip is organized
```text
/pages/<page>/index.html      copy/paste into the CMS body
/pages/<page>/PLACEMENT.md    exact path, title, meta, breadcrumb, redirects, links
/pages/<page>/full-html/index.html  full-page file-upload fallback
/metadata-all.csv             all page titles, meta, canonical, store, schema
/README-DEALERON.md           this file
/EMAIL-DRAFT.md               publish-request email text
```

## QA evidence summary
- All 10 pages passed QA at 390px and 1280px.
- No overflow or duplicate content IDs were found.
- Header/nav/footer stayed intact.
- QA screenshots and the full QA table are in the source package at `deliveries/site-packages/2026-11-04/_qa/`.

## Contact
Spencer Heywood — Motor Inn Auto Group — (712) 792-5000
