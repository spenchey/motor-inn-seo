Subject: Publish request — 10 approved Motor Inn content pages

Hi DealerOn Support,

Please publish the 10 approved content pages attached as **dealeron-handoff-2026-11-06.zip** for Motor Inn Auto Group.

Use `/metadata-all.csv` for the titles, meta descriptions, canonical URLs, stores, and schema types. Use `/pages/<page>/PLACEMENT.md` for the exact path, breadcrumb, redirect, and internal-link rules.

The preferred setup is to paste the HTML in `/pages/<page>/index.html` into the page body. If DealerOn prefers a file upload, `/pages/<page>/full-html/index.html` is the full-page fallback.

All ten pages passed mobile and desktop QA with no overflow, no duplicate content IDs, and the expected DealerOn header/nav/footer. Pages and QA screenshots are in the source package dated 2026-11-04.

Please confirm once the ten URLs are live and match the canonical paths in the CSV. If a path already exists, pause for our approval before changing it.

Thanks,
Spencer Heywood
Motor Inn Auto Group
(712) 792-5000
