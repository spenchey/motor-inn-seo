# car-dealership-carroll-iowa — exact mount instructions

**Store:** group
**Requested URL path:** /car-dealership-carroll-iowa
**Page title:** Car Dealership in Carroll, Iowa | Motor Inn Auto Group
**Meta description:** Car dealership in Carroll, Iowa: Toyota and Chevrolet side by side, factory service, and straight answers from a family-owned team.
**Canonical:** https://www.motorinnautogroup.com/car-dealership-carroll-iowa

## Where it belongs
- Publish as a standard DealerOn content page using the existing header/nav/footer.
- Breadcrumb: Home > Car Dealership Carroll Iowa.
- Do not place this page in the main navigation unless Spencer asks for it.
- Do not replace site-wide DealerOn chrome with this page's body.

## Redirects
- No redirect is required for this build.
- If an older draft or test slug was live before this package, 301 that older slug to **/car-dealership-carroll-iowa**.

## Internal links that must point to it
- On page `car-dealer-comparison-carroll-iowa`: `Car dealership in Carroll, Iowa`.
- On page `contactus-money-page`: `Car dealership in Carroll, Iowa`.
- On page `f-150-vs-silverado-1500-carroll`: `Car dealership in Carroll, Iowa`.

## Notes
- Keep the page title and meta description exactly as shown above.
- Keep the page schema types in the body: AutomotiveBusiness, FAQPage, WebSite.
