# testdrive-page — exact mount instructions

**Store:** group
**Requested URL path:** /testdrive.aspx
**Page title:** Schedule a Test Drive in Carroll, Iowa | Motor Inn Auto Group in Carroll, Iowa
**Meta description:** Test drive in Carroll, Iowa at Motor Inn Auto Group. Book online or call.
**Canonical:** https://www.motorinnautogroup.com/testdrive.aspx

## Where it belongs
- Publish as a standard DealerOn content page using the existing header/nav/footer.
- Breadcrumb: Home > Schedule a Test Drive in Carroll, Iowa.
- Do not place this page in the main navigation unless Spencer asks for it.
- Do not replace site-wide DealerOn chrome with this page's body.

## Redirects
- No redirect is required for this build.
- If an older draft or test slug was live before this package, 301 that older slug to **/testdrive.aspx**.

## Internal links that must point to it
- On page `car-dealer-comparison-carroll-iowa`: `book a test drive`.
- On page `car-dealer-comparison-carroll-iowa`: `book a test drive`.
- On page `car-dealer-comparison-carroll-iowa`: `book a test drive`.
- On page `car-dealer-comparison-carroll-iowa`: `Test drive in Carroll, Iowa`.
- On page `car-dealer-comparison-carroll-iowa`: `Book a test drive`.
- On page `car-dealership-carroll-iowa`: `book a test drive`.
- On page `car-dealership-carroll-iowa`: `Test drive in Carroll, Iowa`.
- On page `contactus-money-page`: `book a test drive`.
- On page `contactus-money-page`: `Test drive in Carroll, Iowa`.
- On page `f-150-vs-silverado-1500-carroll`: `Test drive in Carroll, Iowa`.
- On page `f-150-vs-silverado-1500-carroll`: `Book a test drive`.
- On page `highlander-vs-grand-highlander`: `Test drive in Carroll, Iowa`.
- On page `highlander-vs-grand-highlander`: `Book a test drive`.
- On page `testdrive-page`: `Book your test drive online`.
- On page `testdrive-page`: `Book Your Test Drive`.
- On page `toyota/highlander-vs-grand-highlander`: `Test drive in Carroll, Iowa`.
- On page `toyota/highlander-vs-grand-highlander`: `Book a test drive`.
- On page `trim-levels-explained`: `Test drive in Carroll, Iowa`.
- On page `used-trucks-carroll`: `Test drive in Carroll, Iowa`.
- On page `used-trucks-carroll`: `book a test drive`.
- On page `used-trucks-towing-iowa`: `Test drive in Carroll, Iowa`.

## Notes
- Keep the page title and meta description exactly as shown above.
- Keep the page schema types in the body: AutomotiveBusiness, FAQPage, WebSite.
