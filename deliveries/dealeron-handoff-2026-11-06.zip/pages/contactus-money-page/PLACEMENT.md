# contactus-money-page — exact mount instructions

**Store:** group
**Requested URL path:** /contactus.aspx
**Page title:** Car Dealerships in Carroll, Iowa | Motor Inn Auto Group in Carroll, Iowa
**Meta description:** Car dealerships in Carroll, Iowa from Motor Inn Auto Group. Shop, service, or get answers from a family-owned Carroll dealership.
**Canonical:** https://www.motorinnautogroup.com/contactus.aspx

## Where it belongs
- Publish as a standard DealerOn content page using the existing header/nav/footer.
- Breadcrumb: Home > Car Dealerships in Carroll, Iowa.
- Do not place this page in the main navigation unless Spencer asks for it.
- Do not replace site-wide DealerOn chrome with this page's body.

## Redirects
- No redirect is required for this build.
- If an older draft or test slug was live before this package, 301 that older slug to **/contactus.aspx**.

## Internal links that must point to it
- On page `car-dealer-comparison-carroll-iowa`: `contact`.
- On page `car-dealer-comparison-carroll-iowa`: `Contact Motor Inn Auto Group`.
- On page `car-dealership-carroll-iowa`: `Contact Motor Inn Auto Group`.
- On page `f-150-vs-silverado-1500-carroll`: `Contact Motor Inn Auto Group`.
- On page `highlander-vs-grand-highlander`: `Contact Motor Inn Auto Group`.
- On page `highlander-vs-grand-highlander`: `contact the team`.
- On page `testdrive-page`: `Contact Motor Inn Auto Group`.
- On page `toyota/highlander-vs-grand-highlander`: `Contact Motor Inn Auto Group`.
- On page `toyota/highlander-vs-grand-highlander`: `contact the team`.
- On page `trim-levels-explained`: `Contact Motor Inn Auto Group`.
- On page `used-trucks-carroll`: `Contact Motor Inn Auto Group`.
- On page `used-trucks-carroll`: `contact the team`.
- On page `used-trucks-towing-iowa`: `Contact Motor Inn Auto Group`.
- On page `used-trucks-towing-iowa`: `Contact us`.

## Notes
- Keep the page title and meta description exactly as shown above.
- Keep the page schema types in the body: AutoDealer, AutomotiveBusiness, FAQPage, WebSite.
